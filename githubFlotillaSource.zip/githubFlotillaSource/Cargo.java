/*
 * P. Cochran and N. Guidry
 * This is the Cargo subclass of the class ship
 * 9/13/22
 */
public class Cargo extends Ship
{
    private int maxCargoTonnage;
    private int refrigeratedStorage;
    
    public Cargo(int mct, int refSto, String nam,  String nat,  int yer, int len, int dra, int bem)
    {
        super (nam, nat, yer, len, dra, bem);
        maxCargoTonnage = mct;
        refrigeratedStorage = refSto;
    }

    public int getMaxCargoTonnage() {
        return maxCargoTonnage;
    }

    public int getRefrigeratedStorage() {
        return refrigeratedStorage;
    }

    public void setRefrigeratedStorage(int refrigeratedStorage) {
        this.refrigeratedStorage = refrigeratedStorage;
    }

    public String toString()
    {
        String cargoInfo = super.toString()+"Max cargo tonnage: "+ maxCargoTonnage + ", Refrigerated"
                + " storage: "+ refrigeratedStorage;
        return cargoInfo;
    }
}
