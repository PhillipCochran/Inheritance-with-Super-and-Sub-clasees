/*
*P.Cochran and N. Guidry
*Driver class that implements ship class and its inherited subclasses
*9/13/22
*/
import javax.swing.*;
import java.util.*;
import java.io.*;

public class FlotillaDriver {
    public static void main(String[] args) 
    {
        String flotillaFile = "flotilla_data.csv";
        File myFile = new File(flotillaFile);
        ArrayList<Ship> shipList = new ArrayList<>();
        String yachtList = "";
        String cruiseList = "";
        String cargoList = "";
        String ships = "";
        String shipInfo = "Our Flotilla: \n";
        
        String questionFile = "icons/select.png";
        ImageIcon questionIcon = new ImageIcon(questionFile);
        String cruiseFile = "icons/CruiseShip.png";
        ImageIcon cruiseIcon = new ImageIcon(cruiseFile);
        String cargoFile = "icons/CargoShip.png";
        ImageIcon cargoIcon = new ImageIcon(cargoFile);
        String yachtFile = "icons/yacht.png";
        ImageIcon yachtIcon = new ImageIcon(yachtFile);
        
        int userChoice = 0;
        
        String ourShips = "Our Ships: P. Cochran and N. Guidry";
        String allYachts = "All Yachts  P. Cochran and N. Guidry";
        String allCruises = "All Cruise Ships  P. Cochran and N. Guidry";
        String allCargos = "All Cargo Ships  P. Cochran and N. Guidry";
        
        String[] ourShipOptions = {"Cruise Ships", "Cargo Ships", "Yachts", "Quit"};
        
        if (! myFile.exists())
        {
            String errorMessage = "cannot read from file.";
            System.out.println(errorMessage);
        }
        
        try
        {
            Scanner inScan = new Scanner(myFile).useDelimiter("[,\n]");
            while(inScan.hasNext())
            {
                ships = inScan.next();
                switch (ships)
                   {
                    case "YT":
                        String name = inScan.next();
                        int year = inScan.nextInt();
                        String country = inScan.next();
                        int length = inScan.nextInt();
                        int draft = inScan.nextInt();
                        int beam = inScan.nextInt();
                        int numStateRooms = inScan.nextInt();
                        int poolSize = inScan.nextInt();
                        int numDecks = inScan.nextInt();
                        int power = inScan.nextInt();

                        shipList.add(new Yacht(numStateRooms, poolSize, numDecks, power,
                            name, country, year, length, draft, beam));
                        
                        break;
                        
                    case "CG":
                        name = inScan.next();
                        year = inScan.nextInt();
                        country = inScan.next();
                        length = inScan.nextInt();
                        draft = inScan.nextInt();
                        beam = inScan.nextInt();
                        int maxCargoTonnage = inScan.nextInt();
                        int refrigeratedStorage = inScan.nextInt();

                        shipList.add(new Cargo(maxCargoTonnage, refrigeratedStorage,
                            name, country, year, length, draft, beam));

                        break;
                        
                    case "CR":
                        name = inScan.next();
                        year = inScan.nextInt();
                        country = inScan.next();
                        length = inScan.nextInt();
                        draft = inScan.nextInt();
                        beam = inScan.nextInt();
                        int numExecRooms = inScan.nextInt();
                        int doubleBunkRooms = inScan.nextInt();
                        int quadBunkRooms = inScan.nextInt();
                        
                        shipList.add(new Cruise(numExecRooms, doubleBunkRooms, quadBunkRooms,
                            name, country, year, length, draft, beam));
                        
                        break;
                       }
            }
        }
        catch(IOException ioe)
        {    
        }
        
        for(int index = 0; index < shipList.size(); index++)
        {
            if (shipList.get(index) instanceof Yacht)
            {
                yachtList += shipList.get(index) + "\n";
                shipInfo += "     "+shipList.get(index).getName() + ", " + 
                    shipList.get(index).getNation() + ", " + 
                    shipList.get(index).getYearBuilt() + "\n";
            }
            else if(shipList.get(index) instanceof Cruise)
            {
                cruiseList += shipList.get(index) + "\n";
                shipInfo +="     "+ shipList.get(index).getName() + ", " + 
                    shipList.get(index).getNation() + ", " + 
                    shipList.get(index).getYearBuilt() + "\n";
            }
            else if(shipList.get(index) instanceof Cargo)
            {
                cargoList += shipList.get(index) + "\n";
                shipInfo +="     "+ shipList.get(index).getName() + ", " + 
                    shipList.get(index).getNation() + ", " + 
                    shipList.get(index).getYearBuilt() + "\n";
            }
           
        }
       
        
        while(userChoice != 3)
        {
            userChoice = JOptionPane.showOptionDialog(null, shipInfo, ourShips,0, 1,
                    questionIcon, ourShipOptions, ourShipOptions[0]);

                    switch (userChoice)
                    {
                        case 0:
                            JOptionPane.showMessageDialog(null, cruiseList, allCruises,
                                    1, cruiseIcon);
                            break;

                        case 1:
                            JOptionPane.showMessageDialog(null, cargoList, allCargos,
                                    1, cargoIcon);
                            break;

                        case 2: 
                            JOptionPane.showMessageDialog(null, yachtList, allYachts,
                                    1, yachtIcon);
                            break;

                        case 3:
                            break;
                    }
        }  
                        
                
        
        
    }
}
