/*
 * P. Cochran and N. Guidry
 * This is the yacht subclass of the class ship
 * 9/13/22
 */


public class Yacht extends Ship
{
    private int numStateRooms;
    private int poolSize;
    private int numDecks;
    private int power;
    
    public Yacht(int nsr, int pSize, int numDec, int pow,
                String nam,  String nat,  int yer, int len, int dra, int bem)
    {
        super(nam, nat, yer, len, dra, bem);
        numStateRooms = nsr;
        poolSize = pSize;
        numDecks = numDec;
        power = pow;
                 
    }

    public int getNumStateRooms() {
        return numStateRooms;
    }

    public int getPoolSize() {
        return poolSize;
    }

    public int getNumDecks() {
        return numDecks;
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }
            
    public String toString()
    {
       String yachtInfo = super.toString() + " Number of State rooms: "+
               numStateRooms + ", Pool size: "+ poolSize + ", Number of Decks: "+
               numDecks+", Horse power: "+ power  ;
       return yachtInfo;
    }    
    
}
