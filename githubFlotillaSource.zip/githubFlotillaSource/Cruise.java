/*
 * P. Cochran and N. Guidry
 * This is the Cruise subclass of the class ship
 * 9/13/22
 */
public class Cruise extends Ship
{
    private int numExecRooms;
    private int doubleBunkRooms;
    private int quadBunkRooms;
    
    public Cruise (int ner, int dbr, int qbr, String nam,  String nat,  int yer,
                   int len, int dra, int bem)
    {
        super ( nam, nat, yer, len, dra, bem);
        numExecRooms = ner;
        doubleBunkRooms = dbr;
        quadBunkRooms = qbr;
        
    }

    public int getNumExecRooms() {
        return numExecRooms;
    }

    public int getDoubleBunkRooms() {
        return doubleBunkRooms;
    }

    public void setDoubleBunkRooms(int doubleBunkRooms) {
        this.doubleBunkRooms = doubleBunkRooms;
    }

    public int getQuadBunkRooms() {
        return quadBunkRooms;
    }

    public void setQuadBunkRooms(int quadBunkRooms) {
        this.quadBunkRooms = quadBunkRooms;
    }
    
    public String toString()
    {
        String cruiseInfo = super.toString()+ "Number of Executive State Rooms: "+
                numExecRooms + ", Number of double bunk rooms: "+ doubleBunkRooms+
                ", Number of quad-bunk rooms: "+ quadBunkRooms;
        return cruiseInfo;
    }
    
}
